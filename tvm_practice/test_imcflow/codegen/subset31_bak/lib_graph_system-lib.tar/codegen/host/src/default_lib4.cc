#define IMCFLOW_ADDR 2147483648
#define IMCFLOW_LEN 266368
#define INT_ACK_GEN_ADDR 0
#define INT_ACK_GEN_LEN 0
#define IMCFLOW_DEVICE "/dev/uio5"
#define INT_ACK_GEN_DEVICE "/dev/uio4"
#define SET_IDLE_CODE 0
#define SET_RUN_CODE 1
#define SET_PROGRAM_CODE 2
#define STATE_REG_IDX 0
#define PC_REG_IDX 2
#define INTR_DONE_REG_IDX 7
#define INODE_PC_START_P1_ENUM_VAL 0
#define INODE_PC_START_EXTERN_ENUM_VAL 1
#define INODE_PC_START_P0_ENUM_VAL 2
#define INODE_NUM 4
#define INODE_0_0_IMEM_BASE_ADDR 128
#define INODE_0_0_POLICY_BASE_ADDR 1152
#define IMCE_0_1_POLICY_BASE_ADDR 1344
#define IMCE_0_2_POLICY_BASE_ADDR 1504
#define IMCE_0_3_POLICY_BASE_ADDR 1632
#define IMCE_0_4_POLICY_BASE_ADDR 1728
#define IMCE_0_1_IMEM_BASE_ADDR 1792
#define IMCE_0_2_IMEM_BASE_ADDR 1824
#define IMCE_0_3_IMEM_BASE_ADDR 1856
#define IMCE_0_4_IMEM_BASE_ADDR 1888
#define INODE_1_0_IMEM_BASE_ADDR 66688
#define INODE_1_0_POLICY_BASE_ADDR 67712
#define IMCE_1_1_POLICY_BASE_ADDR 67936
#define IMCE_1_2_POLICY_BASE_ADDR 68128
#define IMCE_1_3_POLICY_BASE_ADDR 68288
#define IMCE_1_4_POLICY_BASE_ADDR 68384
#define IMCE_1_1_IMEM_BASE_ADDR 68448
#define IMCE_1_2_IMEM_BASE_ADDR 68480
#define IMCE_1_3_IMEM_BASE_ADDR 68512
#define IMCE_1_4_IMEM_BASE_ADDR 68544
#define INODE_2_0_IMEM_BASE_ADDR 133248
#define INODE_2_0_POLICY_BASE_ADDR 134272
#define IMCE_2_1_POLICY_BASE_ADDR 134464
#define IMCE_2_2_POLICY_BASE_ADDR 134624
#define IMCE_2_3_POLICY_BASE_ADDR 134784
#define IMCE_2_4_POLICY_BASE_ADDR 134912
#define IMCE_2_1_IMEM_BASE_ADDR 135008
#define IMCE_2_2_IMEM_BASE_ADDR 135040
#define IMCE_2_3_IMEM_BASE_ADDR 135072
#define IMCE_2_4_IMEM_BASE_ADDR 135104
#define INODE_3_0_IMEM_BASE_ADDR 199808
#define INODE_3_0_POLICY_BASE_ADDR 200832
#define IMCE_3_1_POLICY_BASE_ADDR 201056
#define IMCE_3_2_POLICY_BASE_ADDR 201280
#define IMCE_3_3_POLICY_BASE_ADDR 201472
#define IMCE_3_4_POLICY_BASE_ADDR 201632
#define IMCE_3_1_IMEM_BASE_ADDR 201792
#define IMCE_3_2_IMEM_BASE_ADDR 201824
#define IMCE_3_3_IMEM_BASE_ADDR 201856
#define IMCE_3_4_IMEM_BASE_ADDR 201888
#define SM98_D112LHS_CNT_BASE_ADDR_BASE_ADDR 9344
#define SM99_D112RHS_CNT_BASE_ADDR_BASE_ADDR 75904
#define S112_D113FUNC_OUT0_CNT_BASE_ADDR_BASE_ADDR 209024
#define LHS_m98_BASE_ADDR 1152
#define RHS_m99_BASE_ADDR 67712
#define FUNC_OUT0_112_BASE_ADDR 200832
#include <stdlib.h>
#include <string.h>
#include <tvm/runtime/c_runtime_api.h>
#include <tvm/runtime/c_backend_api.h>
#include <dlpack/dlpack.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
extern "C" { 
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_0_0_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_0_0_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_0_0_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_0_0_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_1_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_1_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_2_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_2_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_3_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_3_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_4_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_4_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_1_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_1_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_2_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_2_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_3_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_3_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_4_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_4_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_1_0_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_1_0_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_1_0_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_1_0_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_1_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_1_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_2_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_2_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_3_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_3_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_4_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_4_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_1_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_1_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_2_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_2_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_3_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_3_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_4_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_4_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_2_0_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_2_0_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_2_0_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_2_0_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_1_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_1_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_2_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_2_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_3_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_3_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_4_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_4_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_1_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_1_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_2_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_2_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_3_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_3_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_4_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_4_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_3_0_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_3_0_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_3_0_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_3_0_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_1_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_1_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_2_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_2_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_3_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_3_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_4_policy_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_4_policy_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_1_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_1_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_2_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_2_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_3_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_3_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_4_imem_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_4_imem_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_sm98_d112lhs_cnt_base_addr_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_sm98_d112lhs_cnt_base_addr_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_sm99_d112rhs_cnt_base_addr_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_sm99_d112rhs_cnt_base_addr_bin_end[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_s112_d113func_out0_cnt_base_addr_bin_start[];
  extern const int32_t _binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_s112_d113func_out0_cnt_base_addr_bin_end[];
}
static inline void enable_imcflow_interrupt(int fd)
{
  uint32_t info = 1;
  ssize_t nb = write(fd, &info, sizeof(info));
  if (nb != (ssize_t)sizeof(info)) {
    perror("write failed");
    close(fd);
    exit(1);
  }
}
static inline void wait_imcflow_interrupt(int fd)
{
  uint32_t info;
  ssize_t nb = read(fd, &info, sizeof(info));
}
static inline void generate_ack(uint32_t* int_ack_gen)
{
  int_ack_gen[0] = 0b1;
}
// Poll until ImcFlow returns to IDLE state
#define POLL_LOG_INTERVAL 1000
static void wait_for_idle(volatile uint32_t* npu_pointer) {
  uint32_t poll_count = 0;
  uint32_t state;
  fprintf(stderr,"[POLLING] Waiting for ImcFlow to return to IDLE state...\n");
  while (1) {
    state = npu_pointer[STATE_REG_IDX];
    if (state == SET_IDLE_CODE) {
      fprintf(stderr,"[POLLING] Operation complete! (polled %u times)\n", poll_count);
      return;
    }
    poll_count++;
    // Log progress every 100k polls for debugging
    if (poll_count % POLL_LOG_INTERVAL == 0) {
      fprintf(stderr,"[POLLING] Still waiting... (poll count: %u, current state: 0x%x)\n",
             poll_count, state);
    }
  }
}
void tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_kernel(int16_t* tvmgen_default_imcflow_main_46_round_imcflow_region4_20_i0, int16_t* tvmgen_default_imcflow_main_46_round_imcflow_region4_20_i1, int16_t* out0) {
  fprintf(stderr,"tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_kernel called\n");
      uint32_t* npu_pointer = (uint32_t*)IMCFLOW_ADDR;
      uint32_t* int_ack_gen_pointer = (uint32_t*)INT_ACK_GEN_ADDR;
  // Transfer data into NPU memory
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_0_0_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_0_0_imem_bin_start); i++){
    npu_pointer[(INODE_0_0_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_0_0_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_0_0_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_0_0_policy_bin_start); i++){
    npu_pointer[(INODE_0_0_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_0_0_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_1_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_1_policy_bin_start); i++){
    npu_pointer[(IMCE_0_1_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_1_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_2_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_2_policy_bin_start); i++){
    npu_pointer[(IMCE_0_2_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_2_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_3_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_3_policy_bin_start); i++){
    npu_pointer[(IMCE_0_3_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_3_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_4_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_4_policy_bin_start); i++){
    npu_pointer[(IMCE_0_4_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_4_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_1_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_1_imem_bin_start); i++){
    npu_pointer[(IMCE_0_1_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_1_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_2_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_2_imem_bin_start); i++){
    npu_pointer[(IMCE_0_2_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_2_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_3_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_3_imem_bin_start); i++){
    npu_pointer[(IMCE_0_3_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_3_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_4_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_4_imem_bin_start); i++){
    npu_pointer[(IMCE_0_4_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_0_4_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_1_0_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_1_0_imem_bin_start); i++){
    npu_pointer[(INODE_1_0_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_1_0_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_1_0_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_1_0_policy_bin_start); i++){
    npu_pointer[(INODE_1_0_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_1_0_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_1_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_1_policy_bin_start); i++){
    npu_pointer[(IMCE_1_1_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_1_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_2_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_2_policy_bin_start); i++){
    npu_pointer[(IMCE_1_2_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_2_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_3_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_3_policy_bin_start); i++){
    npu_pointer[(IMCE_1_3_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_3_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_4_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_4_policy_bin_start); i++){
    npu_pointer[(IMCE_1_4_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_4_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_1_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_1_imem_bin_start); i++){
    npu_pointer[(IMCE_1_1_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_1_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_2_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_2_imem_bin_start); i++){
    npu_pointer[(IMCE_1_2_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_2_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_3_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_3_imem_bin_start); i++){
    npu_pointer[(IMCE_1_3_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_3_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_4_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_4_imem_bin_start); i++){
    npu_pointer[(IMCE_1_4_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_1_4_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_2_0_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_2_0_imem_bin_start); i++){
    npu_pointer[(INODE_2_0_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_2_0_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_2_0_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_2_0_policy_bin_start); i++){
    npu_pointer[(INODE_2_0_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_2_0_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_1_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_1_policy_bin_start); i++){
    npu_pointer[(IMCE_2_1_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_1_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_2_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_2_policy_bin_start); i++){
    npu_pointer[(IMCE_2_2_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_2_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_3_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_3_policy_bin_start); i++){
    npu_pointer[(IMCE_2_3_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_3_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_4_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_4_policy_bin_start); i++){
    npu_pointer[(IMCE_2_4_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_4_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_1_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_1_imem_bin_start); i++){
    npu_pointer[(IMCE_2_1_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_1_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_2_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_2_imem_bin_start); i++){
    npu_pointer[(IMCE_2_2_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_2_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_3_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_3_imem_bin_start); i++){
    npu_pointer[(IMCE_2_3_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_3_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_4_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_4_imem_bin_start); i++){
    npu_pointer[(IMCE_2_4_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_2_4_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_3_0_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_3_0_imem_bin_start); i++){
    npu_pointer[(INODE_3_0_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_3_0_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_3_0_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_3_0_policy_bin_start); i++){
    npu_pointer[(INODE_3_0_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_inode_3_0_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_1_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_1_policy_bin_start); i++){
    npu_pointer[(IMCE_3_1_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_1_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_2_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_2_policy_bin_start); i++){
    npu_pointer[(IMCE_3_2_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_2_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_3_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_3_policy_bin_start); i++){
    npu_pointer[(IMCE_3_3_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_3_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_4_policy_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_4_policy_bin_start); i++){
    npu_pointer[(IMCE_3_4_POLICY_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_4_policy_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_1_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_1_imem_bin_start); i++){
    npu_pointer[(IMCE_3_1_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_1_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_2_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_2_imem_bin_start); i++){
    npu_pointer[(IMCE_3_2_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_2_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_3_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_3_imem_bin_start); i++){
    npu_pointer[(IMCE_3_3_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_3_imem_bin_start)[i];
  }
  for(int i=0; i<(size_t)(_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_4_imem_bin_end-_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_4_imem_bin_start); i++){
    npu_pointer[(IMCE_3_4_IMEM_BASE_ADDR / 4) + i] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_imce_3_4_imem_bin_start)[i];
  }
  // Transfer data into NPU memory
  // Set the inode pc to 0 and run.
  for(int i=0; i<INODE_NUM; i++) {
    npu_pointer[(PC_REG_IDX + i)] = (INODE_PC_START_EXTERN_ENUM_VAL << 30 + 0);
  }
   npu_pointer[STATE_REG_IDX] = SET_PROGRAM_CODE;
  wait_for_idle(npu_pointer);
  npu_pointer[INTR_DONE_REG_IDX] = 1;
  for(int i=0; i<INODE_NUM; i++) {
    npu_pointer[(PC_REG_IDX + i)] = (INODE_PC_START_P1_ENUM_VAL << 30 + 0);
  }
  npu_pointer[STATE_REG_IDX] = SET_RUN_CODE;
  wait_for_idle(npu_pointer);
  npu_pointer[INTR_DONE_REG_IDX] = 1;
  // Tiled execution with factor 1
  fprintf(stderr,"Starting tiled execution with factor 1\n");
  fprintf(stderr,"-- Tiled execution: TILE 0 / 1 --\n");
  // Transfer data into NPU memory
    npu_pointer[(SM98_D112LHS_CNT_BASE_ADDR_BASE_ADDR / 4)] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_sm98_d112lhs_cnt_base_addr_bin_start)[0];
  for(int i=1; i<8; i++){
    npu_pointer[(SM98_D112LHS_CNT_BASE_ADDR_BASE_ADDR / 4) + i] = 0;
  }
    npu_pointer[(SM99_D112RHS_CNT_BASE_ADDR_BASE_ADDR / 4)] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_sm99_d112rhs_cnt_base_addr_bin_start)[0];
  for(int i=1; i<8; i++){
    npu_pointer[(SM99_D112RHS_CNT_BASE_ADDR_BASE_ADDR / 4) + i] = 0;
  }
    npu_pointer[(S112_D113FUNC_OUT0_CNT_BASE_ADDR_BASE_ADDR / 4)] = ((uint32_t*)_binary_tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_s112_d113func_out0_cnt_base_addr_bin_start)[0];
  for(int i=1; i<8; i++){
    npu_pointer[(S112_D113FUNC_OUT0_CNT_BASE_ADDR_BASE_ADDR / 4) + i] = 0;
  }
  // Transfer data into NPU memory
  // Transfer data [TILE:0]
  fprintf(stderr,"Transferring input block to NPU [TILE:0]\n");
  for(int i=0; i<2048; i++){
    npu_pointer[(LHS_m98_BASE_ADDR / 4) + i] = ((uint32_t*)tvmgen_default_imcflow_main_46_round_imcflow_region4_20_i0)[i + 0];
  }
  // Transfer data [TILE:0]
  fprintf(stderr,"Transferring input block to NPU [TILE:0]\n");
  for(int i=0; i<2048; i++){
    npu_pointer[(RHS_m99_BASE_ADDR / 4) + i] = ((uint32_t*)tvmgen_default_imcflow_main_46_round_imcflow_region4_20_i1)[i + 0];
  }
  for(int i=0; i<INODE_NUM; i++) {
    npu_pointer[(PC_REG_IDX + i)] = (INODE_PC_START_P1_ENUM_VAL << 30 + 0);
  }
  npu_pointer[STATE_REG_IDX] = SET_RUN_CODE;
  wait_for_idle(npu_pointer);
  npu_pointer[INTR_DONE_REG_IDX] = 1;
  // Transfer data from NPU memory
  // Transfer data [TILE:0]
  fprintf(stderr,"Transferring output block to out0 [TILE:0]\n");
  for(int i=0; i<2048; i++){
    ((uint32_t*)out0)[i + 0] = npu_pointer[(FUNC_OUT0_112_BASE_ADDR / 4) + i];
  }
}
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  (void)resource_handle;
  if (num_args < 2) return -1;
  void* _in0 = (((TVMValue*)args)[0].v_handle);
  DLTensor* in0 = (DLTensor*)_in0;
  void* _in1 = (((TVMValue*)args)[1].v_handle);
  DLTensor* in1 = (DLTensor*)_in1;
  void* _out0 = (((TVMValue*)args)[2].v_handle);
  DLTensor* out0 = (DLTensor*)_out0;
  tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20_kernel((int16_t*)in0->data, (int16_t*)in1->data, (int16_t*)out0->data);
  (void)out_ret_value;
  if (out_ret_tcode) { *out_ret_tcode = kTVMArgInt; }
  return 0;
}