#include <tvm/runtime/crt/module.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region1_main_0(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region3_main_12(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region2_main_5(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_1(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_2(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_1(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_clip(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_expand_dims(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_1(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_2(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_3(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_4(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_5(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_6(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_1(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_2(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_3(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_negative(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_adaptive_avg_pool2d(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_batch_flatten(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_bias_add(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_relu(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_rsqrt(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_strided_slice(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_strided_slice_1(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code, void* resource_handle);
static TVMBackendPackedCFunc _tvm_func_array[] = {
    (TVMBackendPackedCFunc)tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region1_main_0,
    (TVMBackendPackedCFunc)tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20,
    (TVMBackendPackedCFunc)tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region3_main_12,
    (TVMBackendPackedCFunc)tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region2_main_5,
    (TVMBackendPackedCFunc)tvmgen_default_fused_add,
    (TVMBackendPackedCFunc)tvmgen_default_fused_add_1,
    (TVMBackendPackedCFunc)tvmgen_default_fused_add_2,
    (TVMBackendPackedCFunc)tvmgen_default_fused_cast,
    (TVMBackendPackedCFunc)tvmgen_default_fused_cast_1,
    (TVMBackendPackedCFunc)tvmgen_default_fused_clip,
    (TVMBackendPackedCFunc)tvmgen_default_fused_expand_dims,
    (TVMBackendPackedCFunc)tvmgen_default_fused_layout_transform,
    (TVMBackendPackedCFunc)tvmgen_default_fused_layout_transform_1,
    (TVMBackendPackedCFunc)tvmgen_default_fused_layout_transform_2,
    (TVMBackendPackedCFunc)tvmgen_default_fused_layout_transform_3,
    (TVMBackendPackedCFunc)tvmgen_default_fused_layout_transform_4,
    (TVMBackendPackedCFunc)tvmgen_default_fused_layout_transform_5,
    (TVMBackendPackedCFunc)tvmgen_default_fused_layout_transform_6,
    (TVMBackendPackedCFunc)tvmgen_default_fused_multiply,
    (TVMBackendPackedCFunc)tvmgen_default_fused_multiply_1,
    (TVMBackendPackedCFunc)tvmgen_default_fused_multiply_2,
    (TVMBackendPackedCFunc)tvmgen_default_fused_multiply_3,
    (TVMBackendPackedCFunc)tvmgen_default_fused_negative,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_adaptive_avg_pool2d,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_batch_flatten,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_bias_add,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_dense,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_relu,
    (TVMBackendPackedCFunc)tvmgen_default_fused_rsqrt,
    (TVMBackendPackedCFunc)tvmgen_default_fused_strided_slice,
    (TVMBackendPackedCFunc)tvmgen_default_fused_strided_slice_1,
};
static const TVMFuncRegistry _tvm_func_registry = {
    " \000tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region1_main_0\000tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region4_main_20\000tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region3_main_12\000tvmgen_default_tvmgen_default_imcflow_main_46_round_imcflow_region2_main_5\000tvmgen_default_fused_add\000tvmgen_default_fused_add_1\000tvmgen_default_fused_add_2\000tvmgen_default_fused_cast\000tvmgen_default_fused_cast_1\000tvmgen_default_fused_clip\000tvmgen_default_fused_expand_dims\000tvmgen_default_fused_layout_transform\000tvmgen_default_fused_layout_transform_1\000tvmgen_default_fused_layout_transform_2\000tvmgen_default_fused_layout_transform_3\000tvmgen_default_fused_layout_transform_4\000tvmgen_default_fused_layout_transform_5\000tvmgen_default_fused_layout_transform_6\000tvmgen_default_fused_multiply\000tvmgen_default_fused_multiply_1\000tvmgen_default_fused_multiply_2\000tvmgen_default_fused_multiply_3\000tvmgen_default_fused_negative\000tvmgen_default_fused_nn_adaptive_avg_pool2d\000tvmgen_default_fused_nn_batch_flatten\000tvmgen_default_fused_nn_bias_add\000tvmgen_default_fused_nn_conv2d\000tvmgen_default_fused_nn_dense\000tvmgen_default_fused_nn_relu\000tvmgen_default_fused_rsqrt\000tvmgen_default_fused_strided_slice\000tvmgen_default_fused_strided_slice_1\000",    _tvm_func_array,
};
static const TVMModule _tvm_system_lib = {
    &_tvm_func_registry,
};
const TVMModule* TVMSystemLibEntryPoint(void) {
    return &_tvm_system_lib;
}
;