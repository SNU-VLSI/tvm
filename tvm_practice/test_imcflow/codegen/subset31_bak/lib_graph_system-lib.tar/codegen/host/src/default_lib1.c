// tvm target: c -keys=cpu 
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_2(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_clip(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_expand_dims(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_2(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_3(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_4(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_5(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_6(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_2(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_3(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_negative(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_adaptive_avg_pool2d(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_batch_flatten(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_bias_add(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_relu(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_rsqrt(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_strided_slice(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_strided_slice_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL float sqrtf(float);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t T_add_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* T_add = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_add_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_add_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_add_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_add_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_add_T_add_shape = (((DLTensor*)T_add)[0].shape);
  void* tvmgen_default_fused_add_T_add_strides = (((DLTensor*)T_add)[0].strides);
  void* T_add_1 = (((DLTensor*)T_add)[0].data);
  if (!(tvmgen_default_fused_add_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_add_T_add_strides == NULL)) {
  }
  for (int32_t ax0_inner = 0; ax0_inner < 16; ++ax0_inner) {
    ((float*)T_add_1)[ax0_inner] = (((float*)p0_1)[ax0_inner] + ((float*)p1_1)[0]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t T_add_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* T_add = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_add_1_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_add_1_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_add_1_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_add_1_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_add_1_T_add_shape = (((DLTensor*)T_add)[0].shape);
  void* tvmgen_default_fused_add_1_T_add_strides = (((DLTensor*)T_add)[0].strides);
  void* T_add_1 = (((DLTensor*)T_add)[0].data);
  if (!(tvmgen_default_fused_add_1_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_add_1_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_add_1_T_add_strides == NULL)) {
  }
  for (int32_t ax0_inner = 0; ax0_inner < 16; ++ax0_inner) {
    ((float*)T_add_1)[ax0_inner] = (((float*)p0_1)[ax0_inner] + ((float*)p1_1)[ax0_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_add_2(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t T_add_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* T_add = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_add_2_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_add_2_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_add_2_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_add_2_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_add_2_T_add_shape = (((DLTensor*)T_add)[0].shape);
  void* tvmgen_default_fused_add_2_T_add_strides = (((DLTensor*)T_add)[0].strides);
  void* T_add_1 = (((DLTensor*)T_add)[0].data);
  if (!(tvmgen_default_fused_add_2_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_add_2_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_add_2_T_add_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 32; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_1 = ((((ax0_ax1_fused * 1024) + (ax2 * 32)) + (ax3_outer * 16)) + ax3_inner);
          ((float*)T_add_1)[cse_var_1] = (((float*)p0_1)[cse_var_1] + ((float*)p1_1)[ax0_ax1_fused]);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_cast_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_cast = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_cast_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_cast_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_cast_T_cast_shape = (((DLTensor*)T_cast)[0].shape);
  void* tvmgen_default_fused_cast_T_cast_strides = (((DLTensor*)T_cast)[0].strides);
  void* T_cast_1 = (((DLTensor*)T_cast)[0].data);
  if (!(tvmgen_default_fused_cast_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_cast_T_cast_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 32; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_1 = ((((ax0_ax1_fused * 1024) + (ax2 * 32)) + (ax3_outer * 16)) + ax3_inner);
          ((int16_t*)T_cast_1)[cse_var_1] = ((int16_t)((float*)p0_1)[cse_var_1]);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_cast_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_cast = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_cast_1_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_cast_1_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_cast_1_T_cast_shape = (((DLTensor*)T_cast)[0].shape);
  void* tvmgen_default_fused_cast_1_T_cast_strides = (((DLTensor*)T_cast)[0].strides);
  void* T_cast_1 = (((DLTensor*)T_cast)[0].data);
  if (!(tvmgen_default_fused_cast_1_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_cast_1_T_cast_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 32; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3 = 0; ax3 < 8; ++ax3) {
      for (int32_t ax4_inner = 0; ax4_inner < 16; ++ax4_inner) {
        int32_t cse_var_1 = (((ax0_ax1_fused_ax2_fused * 128) + (ax3 * 16)) + ax4_inner);
        ((float*)T_cast_1)[cse_var_1] = ((float)((int16_t*)p0_1)[cse_var_1]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_clip(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t compute_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* compute = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_clip_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_clip_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_clip_compute_shape = (((DLTensor*)compute)[0].shape);
  void* tvmgen_default_fused_clip_compute_strides = (((DLTensor*)compute)[0].strides);
  void* compute_1 = (((DLTensor*)compute)[0].data);
  if (!(tvmgen_default_fused_clip_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_clip_compute_strides == NULL)) {
  }
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 16; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 32; ++i2) {
      for (int32_t i3_outer = 0; i3_outer < 2; ++i3_outer) {
        for (int32_t i3_inner = 0; i3_inner < 16; ++i3_inner) {
          int32_t cse_var_1 = ((((i0_i1_fused * 1024) + (i2 * 32)) + (i3_outer * 16)) + i3_inner);
          float v_ = ((float*)p0_1)[cse_var_1];
          float v__1 = (v_) < (3.276700e+04f) ? (v_) : (3.276700e+04f);
          ((float*)compute_1)[cse_var_1] = ((v__1) > (-3.276800e+04f) ? (v__1) : (-3.276800e+04f));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_expand_dims(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_expand_dims_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_expand_dims = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_expand_dims_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_expand_dims_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_expand_dims_T_expand_dims_shape = (((DLTensor*)T_expand_dims)[0].shape);
  void* tvmgen_default_fused_expand_dims_T_expand_dims_strides = (((DLTensor*)T_expand_dims)[0].strides);
  void* T_expand_dims_1 = (((DLTensor*)T_expand_dims)[0].data);
  if (!(tvmgen_default_fused_expand_dims_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_expand_dims_T_expand_dims_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    ((float*)T_expand_dims_1)[ax0_ax1_fused] = ((float*)p0_1)[ax0_ax1_fused];
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_layout_trans_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_layout_trans = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_layout_transform_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_layout_transform_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_layout_transform_T_layout_trans_shape = (((DLTensor*)T_layout_trans)[0].shape);
  void* tvmgen_default_fused_layout_transform_T_layout_trans_strides = (((DLTensor*)T_layout_trans)[0].strides);
  void* T_layout_trans_1 = (((DLTensor*)T_layout_trans)[0].data);
  if (!(tvmgen_default_fused_layout_transform_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_layout_transform_T_layout_trans_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 1024; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax4_inner = 0; ax4_inner < 16; ++ax4_inner) {
      ((int16_t*)T_layout_trans_1)[((ax0_ax1_fused_ax2_fused * 16) + ax4_inner)] = ((int16_t*)p0_1)[((ax4_inner * 1024) + ax0_ax1_fused_ax2_fused)];
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_layout_trans_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_layout_trans = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_layout_transform_1_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_layout_transform_1_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_layout_transform_1_T_layout_trans_shape = (((DLTensor*)T_layout_trans)[0].shape);
  void* tvmgen_default_fused_layout_transform_1_T_layout_trans_strides = (((DLTensor*)T_layout_trans)[0].strides);
  void* T_layout_trans_1 = (((DLTensor*)T_layout_trans)[0].data);
  if (!(tvmgen_default_fused_layout_transform_1_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_layout_transform_1_T_layout_trans_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 64; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 32; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          ((int16_t*)T_layout_trans_1)[((((ax0_ax1_fused * 1024) + (ax2 * 32)) + (ax3_outer * 16)) + ax3_inner)] = ((int16_t*)p0_1)[((((ax2 * 2048) + (ax3_outer * 1024)) + (ax3_inner * 64)) + ax0_ax1_fused)];
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_2(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_layout_trans_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_layout_trans = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_layout_transform_2_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_layout_transform_2_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_layout_transform_2_T_layout_trans_shape = (((DLTensor*)T_layout_trans)[0].shape);
  void* tvmgen_default_fused_layout_transform_2_T_layout_trans_strides = (((DLTensor*)T_layout_trans)[0].strides);
  void* T_layout_trans_1 = (((DLTensor*)T_layout_trans)[0].data);
  if (!(tvmgen_default_fused_layout_transform_2_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_layout_transform_2_T_layout_trans_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 64; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 16; ++ax2) {
      for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
        ((int16_t*)T_layout_trans_1)[(((ax0_ax1_fused * 256) + (ax2 * 16)) + ax3_inner)] = ((int16_t*)p0_1)[(((ax2 * 1024) + (ax3_inner * 64)) + ax0_ax1_fused)];
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_3(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_layout_trans_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_layout_trans = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_layout_transform_3_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_layout_transform_3_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_layout_transform_3_T_layout_trans_shape = (((DLTensor*)T_layout_trans)[0].shape);
  void* tvmgen_default_fused_layout_transform_3_T_layout_trans_strides = (((DLTensor*)T_layout_trans)[0].strides);
  void* T_layout_trans_1 = (((DLTensor*)T_layout_trans)[0].data);
  if (!(tvmgen_default_fused_layout_transform_3_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_layout_transform_3_T_layout_trans_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 256; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3 = 0; ax3 < 2; ++ax3) {
      for (int32_t ax4_inner = 0; ax4_inner < 16; ++ax4_inner) {
        ((int16_t*)T_layout_trans_1)[(((ax0_ax1_fused_ax2_fused * 32) + (ax3 * 16)) + ax4_inner)] = ((int16_t*)p0_1)[(((ax3 * 4096) + (ax4_inner * 256)) + ax0_ax1_fused_ax2_fused)];
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_4(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_layout_trans_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_layout_trans = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_layout_transform_4_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_layout_transform_4_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_layout_transform_4_T_layout_trans_shape = (((DLTensor*)T_layout_trans)[0].shape);
  void* tvmgen_default_fused_layout_transform_4_T_layout_trans_strides = (((DLTensor*)T_layout_trans)[0].strides);
  void* T_layout_trans_1 = (((DLTensor*)T_layout_trans)[0].data);
  if (!(tvmgen_default_fused_layout_transform_4_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_layout_transform_4_T_layout_trans_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 64; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3 = 0; ax3 < 4; ++ax3) {
      for (int32_t ax4_inner = 0; ax4_inner < 16; ++ax4_inner) {
        int32_t cse_var_1 = (((ax0_ax1_fused_ax2_fused * 64) + (ax3 * 16)) + ax4_inner);
        ((int16_t*)T_layout_trans_1)[cse_var_1] = ((int16_t*)p0_1)[cse_var_1];
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_5(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_layout_trans_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_layout_trans = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_layout_transform_5_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_layout_transform_5_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_layout_transform_5_T_layout_trans_shape = (((DLTensor*)T_layout_trans)[0].shape);
  void* tvmgen_default_fused_layout_transform_5_T_layout_trans_strides = (((DLTensor*)T_layout_trans)[0].strides);
  void* T_layout_trans_1 = (((DLTensor*)T_layout_trans)[0].data);
  if (!(tvmgen_default_fused_layout_transform_5_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_layout_transform_5_T_layout_trans_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 32; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3 = 0; ax3 < 8; ++ax3) {
      for (int32_t ax4_inner = 0; ax4_inner < 16; ++ax4_inner) {
        ((int16_t*)T_layout_trans_1)[(((ax0_ax1_fused_ax2_fused * 128) + (ax3 * 16)) + ax4_inner)] = ((int16_t*)p0_1)[(((((ax0_ax1_fused_ax2_fused & 7) * 512) + (ax3 * 64)) + ((ax0_ax1_fused_ax2_fused >> 3) * 16)) + ax4_inner)];
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_6(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_layout_trans_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_layout_trans = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_layout_transform_6_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_layout_transform_6_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_layout_transform_6_T_layout_trans_shape = (((DLTensor*)T_layout_trans)[0].shape);
  void* tvmgen_default_fused_layout_transform_6_T_layout_trans_strides = (((DLTensor*)T_layout_trans)[0].strides);
  void* T_layout_trans_1 = (((DLTensor*)T_layout_trans)[0].data);
  if (!(tvmgen_default_fused_layout_transform_6_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_layout_transform_6_T_layout_trans_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 64; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 8; ++ax2) {
      for (int32_t ax3_inner = 0; ax3_inner < 8; ++ax3_inner) {
        ((float*)T_layout_trans_1)[(((ax0_ax1_fused * 64) + (ax2 * 8)) + ax3_inner)] = ((float*)p0_1)[(((((ax0_ax1_fused >> 4) * 1024) + (ax2 * 128)) + (ax3_inner * 16)) + (ax0_ax1_fused & 15))];
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t T_multiply_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* T_multiply = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_multiply_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_multiply_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_multiply_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_multiply_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_multiply_T_multiply_shape = (((DLTensor*)T_multiply)[0].shape);
  void* tvmgen_default_fused_multiply_T_multiply_strides = (((DLTensor*)T_multiply)[0].strides);
  void* T_multiply_1 = (((DLTensor*)T_multiply)[0].data);
  if (!(tvmgen_default_fused_multiply_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_multiply_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_multiply_T_multiply_strides == NULL)) {
  }
  for (int32_t ax0_inner = 0; ax0_inner < 16; ++ax0_inner) {
    ((float*)T_multiply_1)[ax0_inner] = (((float*)p0_1)[ax0_inner] * ((float*)p1_1)[ax0_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t T_multiply_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* T_multiply = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_multiply_1_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_multiply_1_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_multiply_1_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_multiply_1_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_multiply_1_T_multiply_shape = (((DLTensor*)T_multiply)[0].shape);
  void* tvmgen_default_fused_multiply_1_T_multiply_strides = (((DLTensor*)T_multiply)[0].strides);
  void* T_multiply_1 = (((DLTensor*)T_multiply)[0].data);
  if (!(tvmgen_default_fused_multiply_1_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_multiply_1_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_multiply_1_T_multiply_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 32; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_1 = ((((ax0_ax1_fused * 1024) + (ax2 * 32)) + (ax3_outer * 16)) + ax3_inner);
          ((float*)T_multiply_1)[cse_var_1] = (((float*)p0_1)[cse_var_1] * ((float*)p1_1)[ax0_ax1_fused]);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_2(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t T_multiply_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* T_multiply = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_multiply_2_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_multiply_2_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_multiply_2_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_multiply_2_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_multiply_2_T_multiply_shape = (((DLTensor*)T_multiply)[0].shape);
  void* tvmgen_default_fused_multiply_2_T_multiply_strides = (((DLTensor*)T_multiply)[0].strides);
  void* T_multiply_1 = (((DLTensor*)T_multiply)[0].data);
  if (!(tvmgen_default_fused_multiply_2_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_multiply_2_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_multiply_2_T_multiply_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 32; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_1 = ((((ax0_ax1_fused * 1024) + (ax2 * 32)) + (ax3_outer * 16)) + ax3_inner);
          ((float*)T_multiply_1)[cse_var_1] = (((float*)p0_1)[cse_var_1] * ((float*)p1_1)[0]);
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_multiply_3(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t T_multiply_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* T_multiply = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_multiply_3_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_multiply_3_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_multiply_3_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_multiply_3_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_multiply_3_T_multiply_shape = (((DLTensor*)T_multiply)[0].shape);
  void* tvmgen_default_fused_multiply_3_T_multiply_strides = (((DLTensor*)T_multiply)[0].strides);
  void* T_multiply_1 = (((DLTensor*)T_multiply)[0].data);
  if (!(tvmgen_default_fused_multiply_3_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_multiply_3_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_multiply_3_T_multiply_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 32; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3 = 0; ax3 < 8; ++ax3) {
      for (int32_t ax4_inner = 0; ax4_inner < 16; ++ax4_inner) {
        int32_t cse_var_1 = (((ax0_ax1_fused_ax2_fused * 128) + (ax3 * 16)) + ax4_inner);
        ((float*)T_multiply_1)[cse_var_1] = (((float*)p0_1)[cse_var_1] * ((float*)p1_1)[0]);
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_negative(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_negative_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_negative = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_negative_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_negative_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_negative_T_negative_shape = (((DLTensor*)T_negative)[0].shape);
  void* tvmgen_default_fused_negative_T_negative_strides = (((DLTensor*)T_negative)[0].strides);
  void* T_negative_1 = (((DLTensor*)T_negative)[0].data);
  if (!(tvmgen_default_fused_negative_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_negative_T_negative_strides == NULL)) {
  }
  for (int32_t ax0_inner = 0; ax0_inner < 16; ++ax0_inner) {
    ((float*)T_negative_1)[ax0_inner] = (0.000000e+00f - ((float*)p0_1)[ax0_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_adaptive_avg_pool2d(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t adaptive_pool_avg_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* adaptive_pool_avg = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_nn_adaptive_avg_pool2d_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_nn_adaptive_avg_pool2d_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_nn_adaptive_avg_pool2d_adaptive_pool_avg_shape = (((DLTensor*)adaptive_pool_avg)[0].shape);
  void* tvmgen_default_fused_nn_adaptive_avg_pool2d_adaptive_pool_avg_strides = (((DLTensor*)adaptive_pool_avg)[0].strides);
  void* adaptive_pool_avg_1 = (((DLTensor*)adaptive_pool_avg)[0].data);
  if (!(tvmgen_default_fused_nn_adaptive_avg_pool2d_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_adaptive_avg_pool2d_adaptive_pool_avg_strides == NULL)) {
  }
  float adaptive_pool_sum[64];
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 64; ++ax0_ax1_fused) {
    adaptive_pool_sum[ax0_ax1_fused] = 0.000000e+00f;
    for (int32_t rv0 = 0; rv0 < 8; ++rv0) {
      for (int32_t rv1 = 0; rv1 < 8; ++rv1) {
        adaptive_pool_sum[ax0_ax1_fused] = (adaptive_pool_sum[ax0_ax1_fused] + ((float*)p0_1)[(((ax0_ax1_fused * 64) + (rv0 * 8)) + rv1)]);
      }
    }
  }
  for (int32_t ax0_ax1_fused_1 = 0; ax0_ax1_fused_1 < 64; ++ax0_ax1_fused_1) {
    ((float*)adaptive_pool_avg_1)[ax0_ax1_fused_1] = (adaptive_pool_sum[ax0_ax1_fused_1] * 1.562500e-02f);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_batch_flatten(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t tensor_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* tensor = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_nn_batch_flatten_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_nn_batch_flatten_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_nn_batch_flatten_tensor_shape = (((DLTensor*)tensor)[0].shape);
  void* tvmgen_default_fused_nn_batch_flatten_tensor_strides = (((DLTensor*)tensor)[0].strides);
  void* tensor_1 = (((DLTensor*)tensor)[0].data);
  if (!(tvmgen_default_fused_nn_batch_flatten_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_batch_flatten_tensor_strides == NULL)) {
  }
  for (int32_t ax1_outer = 0; ax1_outer < 4; ++ax1_outer) {
    for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
      int32_t cse_var_1 = ((ax1_outer * 16) + ax1_inner);
      ((float*)tensor_1)[cse_var_1] = ((float*)p0_1)[cse_var_1];
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_bias_add(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t T_add_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* T_add = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_nn_bias_add_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_nn_bias_add_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_nn_bias_add_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_nn_bias_add_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_nn_bias_add_T_add_shape = (((DLTensor*)T_add)[0].shape);
  void* tvmgen_default_fused_nn_bias_add_T_add_strides = (((DLTensor*)T_add)[0].strides);
  void* T_add_1 = (((DLTensor*)T_add)[0].data);
  if (!(tvmgen_default_fused_nn_bias_add_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_bias_add_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_bias_add_T_add_strides == NULL)) {
  }
  for (int32_t ax1_inner = 0; ax1_inner < 10; ++ax1_inner) {
    ((float*)T_add_1)[ax1_inner] = (((float*)p0_1)[ax1_inner] + ((float*)p1_1)[ax1_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t output_unpack_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* output_unpack = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_nn_conv2d_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_nn_conv2d_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_nn_conv2d_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_nn_conv2d_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_nn_conv2d_output_unpack_shape = (((DLTensor*)output_unpack)[0].shape);
  void* tvmgen_default_fused_nn_conv2d_output_unpack_strides = (((DLTensor*)output_unpack)[0].strides);
  void* output_unpack_1 = (((DLTensor*)output_unpack)[0].data);
  if (!(tvmgen_default_fused_nn_conv2d_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_conv2d_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_conv2d_output_unpack_strides == NULL)) {
  }
  void* data_vec = TVMBackendAllocWorkspace(1, dev_id, (uint64_t)12288, 2, 32);
  if (data_vec == NULL) {
    return -1;
  }
  void* data_pad = TVMBackendAllocWorkspace(1, dev_id, (uint64_t)13872, 2, 32);
  if (data_pad == NULL) {
    return -1;
  }
  for (int32_t bs_c_fused_h_fused = 0; bs_c_fused_h_fused < 32; ++bs_c_fused_h_fused) {
    for (int32_t w = 0; w < 32; ++w) {
      for (int32_t vc = 0; vc < 3; ++vc) {
        ((float*)data_vec)[(((bs_c_fused_h_fused * 96) + (w * 3)) + vc)] = ((float*)p0_1)[(((vc * 1024) + (bs_c_fused_h_fused * 32)) + w)];
      }
    }
  }
  for (int32_t i0_i1_fused_i2_fused = 0; i0_i1_fused_i2_fused < 34; ++i0_i1_fused_i2_fused) {
    for (int32_t i3 = 0; i3 < 34; ++i3) {
      for (int32_t i4 = 0; i4 < 3; ++i4) {
        int32_t cse_var_1 = (i3 * 3);
        float condval;
        if (((((1 <= i0_i1_fused_i2_fused) && (i0_i1_fused_i2_fused < 33)) && (1 <= i3)) && (i3 < 33))) {
          condval = ((float*)data_vec)[((((i0_i1_fused_i2_fused * 96) + cse_var_1) + i4) - 99)];
        } else {
          condval = 0.000000e+00f;
        }
        ((float*)data_pad)[(((i0_i1_fused_i2_fused * 102) + cse_var_1) + i4)] = condval;
      }
    }
  }
  for (int32_t occ_k_h_fused = 0; occ_k_h_fused < 12; ++occ_k_h_fused) {
    for (int32_t k_w = 0; k_w < 3; ++k_w) {
      for (int32_t icb = 0; icb < 3; ++icb) {
        for (int32_t ocb = 0; ocb < 4; ++ocb) {
          ((float*)data_vec)[((((occ_k_h_fused * 36) + (k_w * 12)) + (icb * 4)) + ocb)] = ((float*)p1_1)[((((((occ_k_h_fused / 3) * 108) + (ocb * 27)) + (icb * 9)) + ((occ_k_h_fused % 3) * 3)) + k_w)];
        }
      }
    }
  }
  for (int32_t n_c_outer_fused_h_fused = 0; n_c_outer_fused_h_fused < 128; ++n_c_outer_fused_h_fused) {
    float conv2d_NCHWc[128];
    float conv2d_NCHWc_global[64];
    for (int32_t ow_outer = 0; ow_outer < 2; ++ow_outer) {
      for (int32_t oc_block_c_init = 0; oc_block_c_init < 4; ++oc_block_c_init) {
        conv2d_NCHWc_global[oc_block_c_init] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_1 = 0; oc_block_c_init_1 < 4; ++oc_block_c_init_1) {
        conv2d_NCHWc_global[(oc_block_c_init_1 + 4)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_2 = 0; oc_block_c_init_2 < 4; ++oc_block_c_init_2) {
        conv2d_NCHWc_global[(oc_block_c_init_2 + 8)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_3 = 0; oc_block_c_init_3 < 4; ++oc_block_c_init_3) {
        conv2d_NCHWc_global[(oc_block_c_init_3 + 12)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_4 = 0; oc_block_c_init_4 < 4; ++oc_block_c_init_4) {
        conv2d_NCHWc_global[(oc_block_c_init_4 + 16)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_5 = 0; oc_block_c_init_5 < 4; ++oc_block_c_init_5) {
        conv2d_NCHWc_global[(oc_block_c_init_5 + 20)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_6 = 0; oc_block_c_init_6 < 4; ++oc_block_c_init_6) {
        conv2d_NCHWc_global[(oc_block_c_init_6 + 24)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_7 = 0; oc_block_c_init_7 < 4; ++oc_block_c_init_7) {
        conv2d_NCHWc_global[(oc_block_c_init_7 + 28)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_8 = 0; oc_block_c_init_8 < 4; ++oc_block_c_init_8) {
        conv2d_NCHWc_global[(oc_block_c_init_8 + 32)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_9 = 0; oc_block_c_init_9 < 4; ++oc_block_c_init_9) {
        conv2d_NCHWc_global[(oc_block_c_init_9 + 36)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_10 = 0; oc_block_c_init_10 < 4; ++oc_block_c_init_10) {
        conv2d_NCHWc_global[(oc_block_c_init_10 + 40)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_11 = 0; oc_block_c_init_11 < 4; ++oc_block_c_init_11) {
        conv2d_NCHWc_global[(oc_block_c_init_11 + 44)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_12 = 0; oc_block_c_init_12 < 4; ++oc_block_c_init_12) {
        conv2d_NCHWc_global[(oc_block_c_init_12 + 48)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_13 = 0; oc_block_c_init_13 < 4; ++oc_block_c_init_13) {
        conv2d_NCHWc_global[(oc_block_c_init_13 + 52)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_14 = 0; oc_block_c_init_14 < 4; ++oc_block_c_init_14) {
        conv2d_NCHWc_global[(oc_block_c_init_14 + 56)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_15 = 0; oc_block_c_init_15 < 4; ++oc_block_c_init_15) {
        conv2d_NCHWc_global[(oc_block_c_init_15 + 60)] = 0.000000e+00f;
      }
      for (int32_t kh = 0; kh < 3; ++kh) {
        for (int32_t kw = 0; kw < 3; ++kw) {
          for (int32_t ic_inner = 0; ic_inner < 3; ++ic_inner) {
            for (int32_t oc_block_c = 0; oc_block_c < 4; ++oc_block_c) {
              conv2d_NCHWc_global[oc_block_c] = (conv2d_NCHWc_global[oc_block_c] + (((float*)data_pad)[(((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c)]));
            }
            for (int32_t oc_block_c_1 = 0; oc_block_c_1 < 4; ++oc_block_c_1) {
              int32_t cse_var_2 = (oc_block_c_1 + 4);
              conv2d_NCHWc_global[cse_var_2] = (conv2d_NCHWc_global[cse_var_2] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 3)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_1)]));
            }
            for (int32_t oc_block_c_2 = 0; oc_block_c_2 < 4; ++oc_block_c_2) {
              int32_t cse_var_3 = (oc_block_c_2 + 8);
              conv2d_NCHWc_global[cse_var_3] = (conv2d_NCHWc_global[cse_var_3] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 6)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_2)]));
            }
            for (int32_t oc_block_c_3 = 0; oc_block_c_3 < 4; ++oc_block_c_3) {
              int32_t cse_var_4 = (oc_block_c_3 + 12);
              conv2d_NCHWc_global[cse_var_4] = (conv2d_NCHWc_global[cse_var_4] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 9)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_3)]));
            }
            for (int32_t oc_block_c_4 = 0; oc_block_c_4 < 4; ++oc_block_c_4) {
              int32_t cse_var_5 = (oc_block_c_4 + 16);
              conv2d_NCHWc_global[cse_var_5] = (conv2d_NCHWc_global[cse_var_5] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 12)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_4)]));
            }
            for (int32_t oc_block_c_5 = 0; oc_block_c_5 < 4; ++oc_block_c_5) {
              int32_t cse_var_6 = (oc_block_c_5 + 20);
              conv2d_NCHWc_global[cse_var_6] = (conv2d_NCHWc_global[cse_var_6] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 15)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_5)]));
            }
            for (int32_t oc_block_c_6 = 0; oc_block_c_6 < 4; ++oc_block_c_6) {
              int32_t cse_var_7 = (oc_block_c_6 + 24);
              conv2d_NCHWc_global[cse_var_7] = (conv2d_NCHWc_global[cse_var_7] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 18)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_6)]));
            }
            for (int32_t oc_block_c_7 = 0; oc_block_c_7 < 4; ++oc_block_c_7) {
              int32_t cse_var_8 = (oc_block_c_7 + 28);
              conv2d_NCHWc_global[cse_var_8] = (conv2d_NCHWc_global[cse_var_8] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 21)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_7)]));
            }
            for (int32_t oc_block_c_8 = 0; oc_block_c_8 < 4; ++oc_block_c_8) {
              int32_t cse_var_9 = (oc_block_c_8 + 32);
              conv2d_NCHWc_global[cse_var_9] = (conv2d_NCHWc_global[cse_var_9] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 24)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_8)]));
            }
            for (int32_t oc_block_c_9 = 0; oc_block_c_9 < 4; ++oc_block_c_9) {
              int32_t cse_var_10 = (oc_block_c_9 + 36);
              conv2d_NCHWc_global[cse_var_10] = (conv2d_NCHWc_global[cse_var_10] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 27)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_9)]));
            }
            for (int32_t oc_block_c_10 = 0; oc_block_c_10 < 4; ++oc_block_c_10) {
              int32_t cse_var_11 = (oc_block_c_10 + 40);
              conv2d_NCHWc_global[cse_var_11] = (conv2d_NCHWc_global[cse_var_11] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 30)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_10)]));
            }
            for (int32_t oc_block_c_11 = 0; oc_block_c_11 < 4; ++oc_block_c_11) {
              int32_t cse_var_12 = (oc_block_c_11 + 44);
              conv2d_NCHWc_global[cse_var_12] = (conv2d_NCHWc_global[cse_var_12] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 33)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_11)]));
            }
            for (int32_t oc_block_c_12 = 0; oc_block_c_12 < 4; ++oc_block_c_12) {
              int32_t cse_var_13 = (oc_block_c_12 + 48);
              conv2d_NCHWc_global[cse_var_13] = (conv2d_NCHWc_global[cse_var_13] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 36)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_12)]));
            }
            for (int32_t oc_block_c_13 = 0; oc_block_c_13 < 4; ++oc_block_c_13) {
              int32_t cse_var_14 = (oc_block_c_13 + 52);
              conv2d_NCHWc_global[cse_var_14] = (conv2d_NCHWc_global[cse_var_14] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 39)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_13)]));
            }
            for (int32_t oc_block_c_14 = 0; oc_block_c_14 < 4; ++oc_block_c_14) {
              int32_t cse_var_15 = (oc_block_c_14 + 56);
              conv2d_NCHWc_global[cse_var_15] = (conv2d_NCHWc_global[cse_var_15] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 42)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_14)]));
            }
            for (int32_t oc_block_c_15 = 0; oc_block_c_15 < 4; ++oc_block_c_15) {
              int32_t cse_var_16 = (oc_block_c_15 + 60);
              conv2d_NCHWc_global[cse_var_16] = (conv2d_NCHWc_global[cse_var_16] + (((float*)data_pad)[((((((kh * 102) + ((n_c_outer_fused_h_fused & 31) * 102)) + (ow_outer * 48)) + (kw * 3)) + ic_inner) + 45)] * ((float*)data_vec)[((((((n_c_outer_fused_h_fused >> 5) * 108) + (kh * 36)) + (kw * 12)) + (ic_inner * 4)) + oc_block_c_15)]));
            }
          }
        }
      }
      for (int32_t ow_inner = 0; ow_inner < 16; ++ow_inner) {
        for (int32_t oc_block = 0; oc_block < 4; ++oc_block) {
          int32_t cse_var_17 = (ow_inner * 4);
          conv2d_NCHWc[(((ow_outer * 64) + cse_var_17) + oc_block)] = conv2d_NCHWc_global[(cse_var_17 + oc_block)];
        }
      }
    }
    for (int32_t w_outer = 0; w_outer < 2; ++w_outer) {
      for (int32_t w_inner = 0; w_inner < 16; ++w_inner) {
        for (int32_t c_inner = 0; c_inner < 4; ++c_inner) {
          ((float*)output_unpack_1)[((((((n_c_outer_fused_h_fused >> 5) * 4096) + (c_inner * 1024)) + ((n_c_outer_fused_h_fused & 31) * 32)) + (w_outer * 16)) + w_inner)] = conv2d_NCHWc[(((w_outer * 64) + (w_inner * 4)) + c_inner)];
        }
      }
    }
  }
  if (TVMBackendFreeWorkspace(1, dev_id, data_pad) != 0) {
    return -1;
  }
  if (TVMBackendFreeWorkspace(1, dev_id, data_vec) != 0) {
    return -1;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t compute_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* compute = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_nn_dense_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_nn_dense_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_nn_dense_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_nn_dense_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_nn_dense_compute_shape = (((DLTensor*)compute)[0].shape);
  void* tvmgen_default_fused_nn_dense_compute_strides = (((DLTensor*)compute)[0].strides);
  void* compute_1 = (((DLTensor*)compute)[0].data);
  if (!(tvmgen_default_fused_nn_dense_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_dense_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_dense_compute_strides == NULL)) {
  }
  void* packed_weight = TVMBackendAllocWorkspace(1, dev_id, (uint64_t)2560, 2, 32);
  if (packed_weight == NULL) {
    return -1;
  }
  for (int32_t z = 0; z < 2; ++z) {
    for (int32_t y = 0; y < 64; ++y) {
      for (int32_t x = 0; x < 5; ++x) {
        int32_t cse_var_1 = (z * 320);
        ((float*)packed_weight)[((cse_var_1 + (y * 5)) + x)] = ((float*)p1_1)[((cse_var_1 + (x * 64)) + y)];
      }
    }
  }
  for (int32_t x_outer_y_outer_fused = 0; x_outer_y_outer_fused < 2; ++x_outer_y_outer_fused) {
    float compute_global[5];
    for (int32_t x_c_init = 0; x_c_init < 5; ++x_c_init) {
      compute_global[x_c_init] = 0.000000e+00f;
    }
    for (int32_t k_outer = 0; k_outer < 64; ++k_outer) {
      for (int32_t x_c = 0; x_c < 5; ++x_c) {
        compute_global[x_c] = (compute_global[x_c] + (((float*)p0_1)[k_outer] * ((float*)packed_weight)[(((x_outer_y_outer_fused * 320) + (k_outer * 5)) + x_c)]));
      }
    }
    for (int32_t x_inner_inner = 0; x_inner_inner < 5; ++x_inner_inner) {
      ((float*)compute_1)[((x_outer_y_outer_fused * 5) + x_inner_inner)] = compute_global[x_inner_inner];
    }
  }
  if (TVMBackendFreeWorkspace(1, dev_id, packed_weight) != 0) {
    return -1;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_relu(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_relu_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_relu = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_nn_relu_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_nn_relu_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_nn_relu_T_relu_shape = (((DLTensor*)T_relu)[0].shape);
  void* tvmgen_default_fused_nn_relu_T_relu_strides = (((DLTensor*)T_relu)[0].strides);
  void* T_relu_1 = (((DLTensor*)T_relu)[0].data);
  if (!(tvmgen_default_fused_nn_relu_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_relu_T_relu_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 32; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3 = 0; ax3 < 8; ++ax3) {
      for (int32_t ax4_inner = 0; ax4_inner < 16; ++ax4_inner) {
        int32_t cse_var_1 = (((ax0_ax1_fused_ax2_fused * 128) + (ax3 * 16)) + ax4_inner);
        float v_ = ((float*)p0_1)[cse_var_1];
        ((float*)T_relu_1)[cse_var_1] = ((v_) > (0.000000e+00f) ? (v_) : (0.000000e+00f));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_rsqrt(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t tensor_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* tensor = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_rsqrt_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_rsqrt_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_rsqrt_tensor_shape = (((DLTensor*)tensor)[0].shape);
  void* tvmgen_default_fused_rsqrt_tensor_strides = (((DLTensor*)tensor)[0].strides);
  void* tensor_1 = (((DLTensor*)tensor)[0].data);
  if (!(tvmgen_default_fused_rsqrt_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_rsqrt_tensor_strides == NULL)) {
  }
  for (int32_t ax0_inner = 0; ax0_inner < 16; ++ax0_inner) {
    ((float*)tensor_1)[ax0_inner] = (1.000000e+00f / sqrtf(((float*)p0_1)[ax0_inner]));
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_strided_slice(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_strided_slice_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_strided_slice = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_strided_slice_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_strided_slice_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_strided_slice_T_strided_slice_shape = (((DLTensor*)T_strided_slice)[0].shape);
  void* tvmgen_default_fused_strided_slice_T_strided_slice_strides = (((DLTensor*)T_strided_slice)[0].strides);
  void* T_strided_slice_1 = (((DLTensor*)T_strided_slice)[0].data);
  if (!(tvmgen_default_fused_strided_slice_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_strided_slice_T_strided_slice_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 16; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 32; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          int32_t cse_var_1 = ((((ax0_ax1_fused * 1024) + (ax2 * 32)) + (ax3_outer * 16)) + ax3_inner);
          ((int16_t*)T_strided_slice_1)[cse_var_1] = ((int16_t*)p0_1)[cse_var_1];
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_strided_slice_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_strided_slice_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_strided_slice = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_strided_slice_1_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_strided_slice_1_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_strided_slice_1_T_strided_slice_shape = (((DLTensor*)T_strided_slice)[0].shape);
  void* tvmgen_default_fused_strided_slice_1_T_strided_slice_strides = (((DLTensor*)T_strided_slice)[0].strides);
  void* T_strided_slice_1 = (((DLTensor*)T_strided_slice)[0].data);
  if (!(tvmgen_default_fused_strided_slice_1_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_strided_slice_1_T_strided_slice_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 32; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 16; ++ax2) {
      for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
        int32_t cse_var_1 = (((ax0_ax1_fused * 256) + (ax2 * 16)) + ax3_inner);
        ((int16_t*)T_strided_slice_1)[cse_var_1] = ((int16_t*)p0_1)[cse_var_1];
      }
    }
  }
  return 0;
}

