// tvm target: c -keys=cpu 
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_add_layout_transform(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_global_max_pool2d(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t T_layout_trans_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* T_layout_trans = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_layout_transform_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_layout_transform_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_layout_transform_T_layout_trans_shape = (((DLTensor*)T_layout_trans)[0].shape);
  void* tvmgen_default_fused_layout_transform_T_layout_trans_strides = (((DLTensor*)T_layout_trans)[0].strides);
  void* T_layout_trans_1 = (((DLTensor*)T_layout_trans)[0].data);
  if (!(tvmgen_default_fused_layout_transform_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_layout_transform_T_layout_trans_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 448; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3 = 0; ax3 < 56; ++ax3) {
      for (int32_t ax4_inner = 0; ax4_inner < 4; ++ax4_inner) {
        ((float*)T_layout_trans_1)[(((ax0_ax1_fused_ax2_fused * 224) + (ax3 * 4)) + ax4_inner)] = ((float*)p0_1)[(((((ax0_ax1_fused_ax2_fused / 56) * 12544) + (ax4_inner * 3136)) + ((ax0_ax1_fused_ax2_fused % 56) * 56)) + ax3)];
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_layout_transform_add_layout_transform(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t T_layout_trans_code = arg_type_ids[2];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* T_layout_trans = (((TVMValue*)args)[2].v_handle);
  void* tvmgen_default_fused_layout_transform_add_layout_transform_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_layout_transform_add_layout_transform_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_layout_transform_add_layout_transform_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_layout_transform_add_layout_transform_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_layout_transform_add_layout_transform_T_layout_trans_shape = (((DLTensor*)T_layout_trans)[0].shape);
  void* tvmgen_default_fused_layout_transform_add_layout_transform_T_layout_trans_strides = (((DLTensor*)T_layout_trans)[0].strides);
  void* T_layout_trans_1 = (((DLTensor*)T_layout_trans)[0].data);
  if (!(tvmgen_default_fused_layout_transform_add_layout_transform_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_layout_transform_add_layout_transform_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_layout_transform_add_layout_transform_T_layout_trans_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 32; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 56; ++ax2) {
      for (int32_t ax3_outer = 0; ax3_outer < 4; ++ax3_outer) {
        for (int32_t ax3_inner = 0; ax3_inner < 16; ++ax3_inner) {
          if (((ax3_outer * 2) + (ax3_inner >> 3)) < 7) {
            int32_t cse_var_1 = ((((ax0_ax1_fused * 3136) + (ax2 * 56)) + (ax3_outer * 16)) + ax3_inner);
            ((float*)T_layout_trans_1)[cse_var_1] = (((float*)p1_1)[ax0_ax1_fused] + ((float*)p0_1)[cse_var_1]);
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t p1_code = arg_type_ids[1];
  int32_t p2_code = arg_type_ids[2];
  int32_t T_relu_code = arg_type_ids[3];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* p1 = (((TVMValue*)args)[1].v_handle);
  void* p2 = (((TVMValue*)args)[2].v_handle);
  void* T_relu = (((TVMValue*)args)[3].v_handle);
  void* tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_p1_shape = (((DLTensor*)p1)[0].shape);
  void* tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_p1_strides = (((DLTensor*)p1)[0].strides);
  void* p1_1 = (((DLTensor*)p1)[0].data);
  void* tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_p2_shape = (((DLTensor*)p2)[0].shape);
  void* tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_p2_strides = (((DLTensor*)p2)[0].strides);
  void* p2_1 = (((DLTensor*)p2)[0].data);
  void* tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_T_relu_shape = (((DLTensor*)T_relu)[0].shape);
  void* tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_T_relu_strides = (((DLTensor*)T_relu)[0].strides);
  void* T_relu_1 = (((DLTensor*)T_relu)[0].data);
  if (!(tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_p1_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_p2_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_T_relu_strides == NULL)) {
  }
  void* data_pad = TVMBackendAllocWorkspace(1, dev_id, (uint64_t)430592, 2, 32);
  if (data_pad == NULL) {
    return -1;
  }
  for (int32_t i0_i1_fused_i2_fused = 0; i0_i1_fused_i2_fused < 464; ++i0_i1_fused_i2_fused) {
    for (int32_t i3 = 0; i3 < 58; ++i3) {
      for (int32_t i4 = 0; i4 < 4; ++i4) {
        int32_t cse_var_2 = (i0_i1_fused_i2_fused % 58);
        int32_t cse_var_1 = (i3 * 4);
        float condval;
        if (((((1 <= cse_var_2) && (cse_var_2 < 57)) && (1 <= i3)) && (i3 < 57))) {
          condval = ((float*)p0_1)[((((((i0_i1_fused_i2_fused / 58) * 12544) + (cse_var_2 * 224)) + cse_var_1) + i4) - 228)];
        } else {
          condval = 0.000000e+00f;
        }
        ((float*)data_pad)[(((i0_i1_fused_i2_fused * 232) + cse_var_1) + i4)] = condval;
      }
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 448; ++ax0_ax1_fused_ax2_fused) {
    float conv2d_NCHWc[224];
    float conv2d_NCHWc_global[112];
    for (int32_t ow_outer = 0; ow_outer < 2; ++ow_outer) {
      for (int32_t oc_block_c_init = 0; oc_block_c_init < 4; ++oc_block_c_init) {
        conv2d_NCHWc_global[oc_block_c_init] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_1 = 0; oc_block_c_init_1 < 4; ++oc_block_c_init_1) {
        conv2d_NCHWc_global[(oc_block_c_init_1 + 4)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_2 = 0; oc_block_c_init_2 < 4; ++oc_block_c_init_2) {
        conv2d_NCHWc_global[(oc_block_c_init_2 + 8)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_3 = 0; oc_block_c_init_3 < 4; ++oc_block_c_init_3) {
        conv2d_NCHWc_global[(oc_block_c_init_3 + 12)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_4 = 0; oc_block_c_init_4 < 4; ++oc_block_c_init_4) {
        conv2d_NCHWc_global[(oc_block_c_init_4 + 16)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_5 = 0; oc_block_c_init_5 < 4; ++oc_block_c_init_5) {
        conv2d_NCHWc_global[(oc_block_c_init_5 + 20)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_6 = 0; oc_block_c_init_6 < 4; ++oc_block_c_init_6) {
        conv2d_NCHWc_global[(oc_block_c_init_6 + 24)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_7 = 0; oc_block_c_init_7 < 4; ++oc_block_c_init_7) {
        conv2d_NCHWc_global[(oc_block_c_init_7 + 28)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_8 = 0; oc_block_c_init_8 < 4; ++oc_block_c_init_8) {
        conv2d_NCHWc_global[(oc_block_c_init_8 + 32)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_9 = 0; oc_block_c_init_9 < 4; ++oc_block_c_init_9) {
        conv2d_NCHWc_global[(oc_block_c_init_9 + 36)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_10 = 0; oc_block_c_init_10 < 4; ++oc_block_c_init_10) {
        conv2d_NCHWc_global[(oc_block_c_init_10 + 40)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_11 = 0; oc_block_c_init_11 < 4; ++oc_block_c_init_11) {
        conv2d_NCHWc_global[(oc_block_c_init_11 + 44)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_12 = 0; oc_block_c_init_12 < 4; ++oc_block_c_init_12) {
        conv2d_NCHWc_global[(oc_block_c_init_12 + 48)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_13 = 0; oc_block_c_init_13 < 4; ++oc_block_c_init_13) {
        conv2d_NCHWc_global[(oc_block_c_init_13 + 52)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_14 = 0; oc_block_c_init_14 < 4; ++oc_block_c_init_14) {
        conv2d_NCHWc_global[(oc_block_c_init_14 + 56)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_15 = 0; oc_block_c_init_15 < 4; ++oc_block_c_init_15) {
        conv2d_NCHWc_global[(oc_block_c_init_15 + 60)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_16 = 0; oc_block_c_init_16 < 4; ++oc_block_c_init_16) {
        conv2d_NCHWc_global[(oc_block_c_init_16 + 64)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_17 = 0; oc_block_c_init_17 < 4; ++oc_block_c_init_17) {
        conv2d_NCHWc_global[(oc_block_c_init_17 + 68)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_18 = 0; oc_block_c_init_18 < 4; ++oc_block_c_init_18) {
        conv2d_NCHWc_global[(oc_block_c_init_18 + 72)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_19 = 0; oc_block_c_init_19 < 4; ++oc_block_c_init_19) {
        conv2d_NCHWc_global[(oc_block_c_init_19 + 76)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_20 = 0; oc_block_c_init_20 < 4; ++oc_block_c_init_20) {
        conv2d_NCHWc_global[(oc_block_c_init_20 + 80)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_21 = 0; oc_block_c_init_21 < 4; ++oc_block_c_init_21) {
        conv2d_NCHWc_global[(oc_block_c_init_21 + 84)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_22 = 0; oc_block_c_init_22 < 4; ++oc_block_c_init_22) {
        conv2d_NCHWc_global[(oc_block_c_init_22 + 88)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_23 = 0; oc_block_c_init_23 < 4; ++oc_block_c_init_23) {
        conv2d_NCHWc_global[(oc_block_c_init_23 + 92)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_24 = 0; oc_block_c_init_24 < 4; ++oc_block_c_init_24) {
        conv2d_NCHWc_global[(oc_block_c_init_24 + 96)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_25 = 0; oc_block_c_init_25 < 4; ++oc_block_c_init_25) {
        conv2d_NCHWc_global[(oc_block_c_init_25 + 100)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_26 = 0; oc_block_c_init_26 < 4; ++oc_block_c_init_26) {
        conv2d_NCHWc_global[(oc_block_c_init_26 + 104)] = 0.000000e+00f;
      }
      for (int32_t oc_block_c_init_27 = 0; oc_block_c_init_27 < 4; ++oc_block_c_init_27) {
        conv2d_NCHWc_global[(oc_block_c_init_27 + 108)] = 0.000000e+00f;
      }
      for (int32_t ic_outer = 0; ic_outer < 8; ++ic_outer) {
        for (int32_t kh = 0; kh < 3; ++kh) {
          for (int32_t kw = 0; kw < 3; ++kw) {
            for (int32_t ic_inner = 0; ic_inner < 4; ++ic_inner) {
              for (int32_t oc_block_c = 0; oc_block_c < 4; ++oc_block_c) {
                conv2d_NCHWc_global[oc_block_c] = (conv2d_NCHWc_global[oc_block_c] + (((float*)data_pad)[((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c)]));
              }
              for (int32_t oc_block_c_1 = 0; oc_block_c_1 < 4; ++oc_block_c_1) {
                int32_t cse_var_3 = (oc_block_c_1 + 4);
                conv2d_NCHWc_global[cse_var_3] = (conv2d_NCHWc_global[cse_var_3] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 4)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_1)]));
              }
              for (int32_t oc_block_c_2 = 0; oc_block_c_2 < 4; ++oc_block_c_2) {
                int32_t cse_var_4 = (oc_block_c_2 + 8);
                conv2d_NCHWc_global[cse_var_4] = (conv2d_NCHWc_global[cse_var_4] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 8)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_2)]));
              }
              for (int32_t oc_block_c_3 = 0; oc_block_c_3 < 4; ++oc_block_c_3) {
                int32_t cse_var_5 = (oc_block_c_3 + 12);
                conv2d_NCHWc_global[cse_var_5] = (conv2d_NCHWc_global[cse_var_5] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 12)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_3)]));
              }
              for (int32_t oc_block_c_4 = 0; oc_block_c_4 < 4; ++oc_block_c_4) {
                int32_t cse_var_6 = (oc_block_c_4 + 16);
                conv2d_NCHWc_global[cse_var_6] = (conv2d_NCHWc_global[cse_var_6] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 16)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_4)]));
              }
              for (int32_t oc_block_c_5 = 0; oc_block_c_5 < 4; ++oc_block_c_5) {
                int32_t cse_var_7 = (oc_block_c_5 + 20);
                conv2d_NCHWc_global[cse_var_7] = (conv2d_NCHWc_global[cse_var_7] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 20)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_5)]));
              }
              for (int32_t oc_block_c_6 = 0; oc_block_c_6 < 4; ++oc_block_c_6) {
                int32_t cse_var_8 = (oc_block_c_6 + 24);
                conv2d_NCHWc_global[cse_var_8] = (conv2d_NCHWc_global[cse_var_8] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 24)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_6)]));
              }
              for (int32_t oc_block_c_7 = 0; oc_block_c_7 < 4; ++oc_block_c_7) {
                int32_t cse_var_9 = (oc_block_c_7 + 28);
                conv2d_NCHWc_global[cse_var_9] = (conv2d_NCHWc_global[cse_var_9] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 28)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_7)]));
              }
              for (int32_t oc_block_c_8 = 0; oc_block_c_8 < 4; ++oc_block_c_8) {
                int32_t cse_var_10 = (oc_block_c_8 + 32);
                conv2d_NCHWc_global[cse_var_10] = (conv2d_NCHWc_global[cse_var_10] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 32)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_8)]));
              }
              for (int32_t oc_block_c_9 = 0; oc_block_c_9 < 4; ++oc_block_c_9) {
                int32_t cse_var_11 = (oc_block_c_9 + 36);
                conv2d_NCHWc_global[cse_var_11] = (conv2d_NCHWc_global[cse_var_11] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 36)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_9)]));
              }
              for (int32_t oc_block_c_10 = 0; oc_block_c_10 < 4; ++oc_block_c_10) {
                int32_t cse_var_12 = (oc_block_c_10 + 40);
                conv2d_NCHWc_global[cse_var_12] = (conv2d_NCHWc_global[cse_var_12] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 40)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_10)]));
              }
              for (int32_t oc_block_c_11 = 0; oc_block_c_11 < 4; ++oc_block_c_11) {
                int32_t cse_var_13 = (oc_block_c_11 + 44);
                conv2d_NCHWc_global[cse_var_13] = (conv2d_NCHWc_global[cse_var_13] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 44)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_11)]));
              }
              for (int32_t oc_block_c_12 = 0; oc_block_c_12 < 4; ++oc_block_c_12) {
                int32_t cse_var_14 = (oc_block_c_12 + 48);
                conv2d_NCHWc_global[cse_var_14] = (conv2d_NCHWc_global[cse_var_14] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 48)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_12)]));
              }
              for (int32_t oc_block_c_13 = 0; oc_block_c_13 < 4; ++oc_block_c_13) {
                int32_t cse_var_15 = (oc_block_c_13 + 52);
                conv2d_NCHWc_global[cse_var_15] = (conv2d_NCHWc_global[cse_var_15] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 52)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_13)]));
              }
              for (int32_t oc_block_c_14 = 0; oc_block_c_14 < 4; ++oc_block_c_14) {
                int32_t cse_var_16 = (oc_block_c_14 + 56);
                conv2d_NCHWc_global[cse_var_16] = (conv2d_NCHWc_global[cse_var_16] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 56)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_14)]));
              }
              for (int32_t oc_block_c_15 = 0; oc_block_c_15 < 4; ++oc_block_c_15) {
                int32_t cse_var_17 = (oc_block_c_15 + 60);
                conv2d_NCHWc_global[cse_var_17] = (conv2d_NCHWc_global[cse_var_17] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 60)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_15)]));
              }
              for (int32_t oc_block_c_16 = 0; oc_block_c_16 < 4; ++oc_block_c_16) {
                int32_t cse_var_18 = (oc_block_c_16 + 64);
                conv2d_NCHWc_global[cse_var_18] = (conv2d_NCHWc_global[cse_var_18] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 64)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_16)]));
              }
              for (int32_t oc_block_c_17 = 0; oc_block_c_17 < 4; ++oc_block_c_17) {
                int32_t cse_var_19 = (oc_block_c_17 + 68);
                conv2d_NCHWc_global[cse_var_19] = (conv2d_NCHWc_global[cse_var_19] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 68)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_17)]));
              }
              for (int32_t oc_block_c_18 = 0; oc_block_c_18 < 4; ++oc_block_c_18) {
                int32_t cse_var_20 = (oc_block_c_18 + 72);
                conv2d_NCHWc_global[cse_var_20] = (conv2d_NCHWc_global[cse_var_20] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 72)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_18)]));
              }
              for (int32_t oc_block_c_19 = 0; oc_block_c_19 < 4; ++oc_block_c_19) {
                int32_t cse_var_21 = (oc_block_c_19 + 76);
                conv2d_NCHWc_global[cse_var_21] = (conv2d_NCHWc_global[cse_var_21] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 76)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_19)]));
              }
              for (int32_t oc_block_c_20 = 0; oc_block_c_20 < 4; ++oc_block_c_20) {
                int32_t cse_var_22 = (oc_block_c_20 + 80);
                conv2d_NCHWc_global[cse_var_22] = (conv2d_NCHWc_global[cse_var_22] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 80)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_20)]));
              }
              for (int32_t oc_block_c_21 = 0; oc_block_c_21 < 4; ++oc_block_c_21) {
                int32_t cse_var_23 = (oc_block_c_21 + 84);
                conv2d_NCHWc_global[cse_var_23] = (conv2d_NCHWc_global[cse_var_23] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 84)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_21)]));
              }
              for (int32_t oc_block_c_22 = 0; oc_block_c_22 < 4; ++oc_block_c_22) {
                int32_t cse_var_24 = (oc_block_c_22 + 88);
                conv2d_NCHWc_global[cse_var_24] = (conv2d_NCHWc_global[cse_var_24] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 88)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_22)]));
              }
              for (int32_t oc_block_c_23 = 0; oc_block_c_23 < 4; ++oc_block_c_23) {
                int32_t cse_var_25 = (oc_block_c_23 + 92);
                conv2d_NCHWc_global[cse_var_25] = (conv2d_NCHWc_global[cse_var_25] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 92)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_23)]));
              }
              for (int32_t oc_block_c_24 = 0; oc_block_c_24 < 4; ++oc_block_c_24) {
                int32_t cse_var_26 = (oc_block_c_24 + 96);
                conv2d_NCHWc_global[cse_var_26] = (conv2d_NCHWc_global[cse_var_26] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 96)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_24)]));
              }
              for (int32_t oc_block_c_25 = 0; oc_block_c_25 < 4; ++oc_block_c_25) {
                int32_t cse_var_27 = (oc_block_c_25 + 100);
                conv2d_NCHWc_global[cse_var_27] = (conv2d_NCHWc_global[cse_var_27] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 100)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_25)]));
              }
              for (int32_t oc_block_c_26 = 0; oc_block_c_26 < 4; ++oc_block_c_26) {
                int32_t cse_var_28 = (oc_block_c_26 + 104);
                conv2d_NCHWc_global[cse_var_28] = (conv2d_NCHWc_global[cse_var_28] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 104)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_26)]));
              }
              for (int32_t oc_block_c_27 = 0; oc_block_c_27 < 4; ++oc_block_c_27) {
                int32_t cse_var_29 = (oc_block_c_27 + 108);
                conv2d_NCHWc_global[cse_var_29] = (conv2d_NCHWc_global[cse_var_29] + (((float*)data_pad)[(((((((ic_outer * 13456) + (kh * 232)) + ((ax0_ax1_fused_ax2_fused % 56) * 232)) + (ow_outer * 112)) + (kw * 4)) + ic_inner) + 108)] * ((float*)p1_1)[(((((((ax0_ax1_fused_ax2_fused / 56) * 1152) + (ic_outer * 144)) + (kh * 48)) + (kw * 16)) + (ic_inner * 4)) + oc_block_c_27)]));
              }
            }
          }
        }
      }
      for (int32_t ow_inner = 0; ow_inner < 28; ++ow_inner) {
        for (int32_t oc_block = 0; oc_block < 4; ++oc_block) {
          int32_t cse_var_30 = (ow_inner * 4);
          conv2d_NCHWc[(((ow_outer * 112) + cse_var_30) + oc_block)] = conv2d_NCHWc_global[(cse_var_30 + oc_block)];
        }
      }
    }
    for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
      for (int32_t ax3_inner = 0; ax3_inner < 28; ++ax3_inner) {
        for (int32_t ax4 = 0; ax4 < 4; ++ax4) {
          int32_t cse_var_32 = (ax3_outer * 112);
          int32_t cse_var_31 = (ax3_inner * 4);
          float v_ = conv2d_NCHWc[((cse_var_32 + cse_var_31) + ax4)] + ((float*)p2_1)[(((ax0_ax1_fused_ax2_fused / 56) * 4) + ax4)];
          ((float*)T_relu_1)[((((ax0_ax1_fused_ax2_fused * 224) + cse_var_32) + cse_var_31) + ax4)] = ((v_) > (0.000000e+00f) ? (v_) : (0.000000e+00f));
        }
      }
    }
  }
  if (TVMBackendFreeWorkspace(1, dev_id, data_pad) != 0) {
    return -1;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_global_max_pool2d(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  int32_t p0_code = arg_type_ids[0];
  int32_t adaptive_pool_max_code = arg_type_ids[1];
  void* p0 = (((TVMValue*)args)[0].v_handle);
  void* adaptive_pool_max = (((TVMValue*)args)[1].v_handle);
  void* tvmgen_default_fused_nn_global_max_pool2d_p0_shape = (((DLTensor*)p0)[0].shape);
  void* tvmgen_default_fused_nn_global_max_pool2d_p0_strides = (((DLTensor*)p0)[0].strides);
  int32_t dev_id = (((DLTensor*)p0)[0].device.device_id);
  void* p0_1 = (((DLTensor*)p0)[0].data);
  void* tvmgen_default_fused_nn_global_max_pool2d_adaptive_pool_max_shape = (((DLTensor*)adaptive_pool_max)[0].shape);
  void* tvmgen_default_fused_nn_global_max_pool2d_adaptive_pool_max_strides = (((DLTensor*)adaptive_pool_max)[0].strides);
  void* adaptive_pool_max_1 = (((DLTensor*)adaptive_pool_max)[0].data);
  if (!(tvmgen_default_fused_nn_global_max_pool2d_p0_strides == NULL)) {
  }
  if (!(tvmgen_default_fused_nn_global_max_pool2d_adaptive_pool_max_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 8; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax4 = 0; ax4 < 4; ++ax4) {
      ((float*)adaptive_pool_max_1)[((ax0_ax1_fused_ax2_fused * 4) + ax4)] = -3.402823e+38f;
      for (int32_t rv0 = 0; rv0 < 56; ++rv0) {
        for (int32_t rv1 = 0; rv1 < 56; ++rv1) {
          int32_t cse_var_1 = ((ax0_ax1_fused_ax2_fused * 4) + ax4);
          float v_ = ((float*)adaptive_pool_max_1)[cse_var_1];
          float v__1 = ((float*)p0_1)[((((ax0_ax1_fused_ax2_fused * 12544) + (rv0 * 224)) + (rv1 * 4)) + ax4)];
          ((float*)adaptive_pool_max_1)[cse_var_1] = ((v_) > (v__1) ? (v_) : (v__1));
        }
      }
    }
  }
  return 0;
}

